<?php
include 'connected.php';
if(isset($_POST['ok']))
{
$cid=$_POST['cid1'];
$vacy=$_POST['vacancy'];
$exp=$_POST['exp'];
$sf=$_POST['sfrom'];
$st=$_POST['sto'];
$quali=$_POST['quali'];
$date=$_POST['duedate'];
$sta=$_POST['true'];
$result=pg_query($connect,"insert into vacancyregistration(company,vacancy,experience,salaryfrom,salaryto,qualification,duedate,status) values('$cid','$vacy','$exp','$sf','$st','$quali','$date','$sta')");
    if($result)
    {
         echo"<script>alert('Succesfully registered');</script>";
         header('refresh:0.5,url=vacancy.php');
    }
     else
    {
        echo"<script>alert('Not registered');</script>";
        //header('refresh:0.5,url=vacancy.php');
    }
  }
?>