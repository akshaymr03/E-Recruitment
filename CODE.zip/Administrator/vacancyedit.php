<?php
include 'connected.php';
if(isset($_POST['reset']))
{
$cid=$_POST['cid1'];
$vacy=$_POST['vacancy'];
$exp=$_POST['exp'];
$sf=$_POST['sfrom'];
$st=$_POST['sto'];
$quali=$_POST['quali'];
$date=$_POST['duedate'];
$sta=$_POST['true'];
$r=$_POST['vcode'];
$result=pg_query($connect,"update vacancyregistration set company='$cid',vacancy='$vacy',experience='$exp',salaryfrom='$sf',salaryto='$st',qualification='$quali',duedate='$date',status='$sta' where vacancyid='$r'");
    if($result)
    {
         echo"<script>alert('Succesfully registered');</script>";
         header('refresh:0.5,url=vactable.php');
    }
     else
    {
        echo"<script>alert('Not registered');</script>";
        header('refresh:0.5,url=vacancyupdate.php');
    }
  }
?>