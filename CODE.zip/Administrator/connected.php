<?php
$connect=pg_connect('host=localhost dbname=project user=postgres password=12345');
if(!$connect)
{
	echo 'Invalid data. Unable to connect';
}
?>