<?php
include 'connected.php';
if(isset($_POST['reset']))
{
$cid=$_POST['ccode'];
$cn=$_POST['cname'];
$cnum1=$_POST['cm'];
$cnum2=$_POST['cc'];
$cad=$_POST['loc'];
$cino=$_POST['cin'];
$cem=$_POST['cemail'];
$cty=$_POST['ctype'];
$pin=$_POST['pinc'];
//$p1=$_POST['pword1'];

$s=$_POST['site'];

 
        $result=pg_query($connect,"update companyregistration set cid='$cid',cname='$cn',mobile='$cnum1',telephone='$cnum2',location='$cad',pincode='$pin',cin='$cino',email='$cem',password='$cid',type='$cty',site='$s' where cid='$cid'");
        if($result)
        {
            echo"<script>alert('Succesfully registered');</script>";
            header('refresh:0.5,url=comptable.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            header('refresh:0.5,url=companyupdate.php');
        }

}
?>