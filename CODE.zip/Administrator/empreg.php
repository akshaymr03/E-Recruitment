<?php
include 'connected.php';
if(isset($_POST['ok']))
{
$f1="employee/";
$df1=$f1 . basename($_FILES["pic1"]["name"]);
//$empid=$_POST['eid'];
$en1=$_POST['ename1'];
$en2=$_POST['ename2'];
$en3=$_POST['ename3'];
$an1=$_POST['aadhar1'];
$em=$_POST['email1'];
$ead=$_POST['add'];
$emob=$_POST['emob1'];
$sal=$_POST['salary'];
$desg=$_POST['desg1'];
$pin1=$_POST['pinc1'];
$dat1=$_POST['date1'];
$dat2=$_POST['date2'];
$gen=$_POST['gender'];
$a=uniqid();
$b=substr($a,9);
$empid="EMP/".$b;
$sta=$_POST['status'];
$formate=pathinfo($df1,PATHINFO_EXTENSION);
//if($p1==$p2)
//{
 if (move_uploaded_file($_FILES["pic1"]["tmp_name"], $df1))
 { 
   
        $result=pg_query($connect,"insert into employeeregistration(photo,empid,first,middle,last,gender,aadhar,email,address,mobile,salary,designation,pincode,dateofjoin,dob,password,status) values('$df1','$empid','$en1','$en2','$en3','$gen','$an1','$em','$ead','$emob','$sal','$desg','$pin1','$dat1','$dat2','$empid','$sta')");
        if($result)
        {
            echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=employee.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            //header('refresh:0.5,url=employee.php');
        }
    }
//}
 //else
 //{
    // echo"<script>alert('Password Miss Matching');</script>";
    // header('refresh:0.5,url=employee.php');
 }
?>