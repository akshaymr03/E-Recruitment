<?php
include 'connected.php';
$a=uniqid();
$b=substr($a,9);
$cid="COMP/".$b;
if(isset($_POST['ok']))
{
$f1="photo/";
$df1=$f1 . basename($_FILES["pic"]["name"]);
$f2="signature/";
$df2=$f2 . basename($_FILES["sign"]["name"]);
$pn=$_POST['pname'];
$no=$_POST['pm'];
$aadhar=$_POST['aadhar'];
$em=$_POST['pemail'];

if (move_uploaded_file($_FILES["pic"]["tmp_name"], $df1))
 { 
    if(move_uploaded_file($_FILES["sign"]["tmp_name"], $df2)) 
    {
    $result=pg_query($connect,"insert into proprietor(photo,signature,cid,pname,aadhar,email) values('$df1','$df2','$pn','$no','$aadhar','$em')");
    if($result)
    {
         echo"<script>alert('Succesfully registered');</script>";
         header('refresh:0.5,url=company.php');
    }
     else
    {
        echo"<script>alert('Not registered');</script>";
         header('refresh:0.5,url=proprietor.php');
    }
  }
}
}
?>