<?php
include 'connected.php';
if(isset($_POST['reset']))
{
$f1="photo/";
$df1=$f1 . basename($_FILES["pic"]["name"]);
$f2="signature/";
$df2=$f2 . basename($_FILES["sign"]["name"]);
$pn=$_POST['pname'];
$no=$_POST['pm'];
$aadhar=$_POST['aadhar'];
$em=$_POST['pemail'];
$cid=$_POST['ccode'];

if (move_uploaded_file($_FILES["pic"]["tmp_name"], $df1))
 { 
    if(move_uploaded_file($_FILES["sign"]["tmp_name"], $df2)) 
    {
    $result=pg_query($connect,"update proprietor set photo='$df1',signature='$df2',cid='$cid',pname='$pn',mobile='$no',aadhar='$aadhar',email='$em' where cid='$cid'");
    if($result)
    {
         echo"<script>alert('Succesfully registered');</script>";
         header('refresh:0.5,url=proptable.php');
    }
     else
    {
        echo"<script>alert('Not registered');</script>";
         header('refresh:0.5,url=proprietorupdate.php');
    }
  }
}
}

?>