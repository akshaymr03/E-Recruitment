<?php
include 'connected.php';
if((isset($_GET['res1']))&&(isset($_GET['res2'])))
{
	$r1=$_GET['res1'];
	$r2=$_GET['res2'];
	if($r2=='Active')
	{
	$r3=pg_query($connect,"update vacancyregistration set status='Inactive' where company='$r1'");
	header('location:vactable.php');
	}
	else
	{
	$r3=pg_query($connect,"update vacancyregistration set status='Active' where company='$r1'");
	header('location:vactable.php');
	}
}
?>