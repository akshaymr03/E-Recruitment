<?php
include 'connected.php';
if((isset($_GET['res1']))&&(isset($_GET['res2'])))
{
	$r1=$_GET['res1'];
	$r2=$_GET['res2'];
	if($r2=='Active')
	{
	$r3=pg_query($connect,"update userregistration set status='Inactive' where userid='$r1'");
	header('location:index.php');
	}
	else
	{
	$r3=pg_query($connect,"update userregistration set status='Active' where userid='$r1'");
	header('location:index.php');
	}
}
?>