<?php
include 'connected.php';
if(isset($_POST['okay']))
{
$cid=$_POST['cid1'];
$cn=$_POST['cname'];
$cnum1=$_POST['cm'];
$cnum2=$_POST['cc'];
$cad=$_POST['loc'];
$cino=$_POST['cin'];
$cem=$_POST['cemail'];
$cty=$_POST['ctype'];
$pin=$_POST['pinc'];
$sta=$_POST['status'];
$f1="logo/";
$df1=$f1 . basename($_FILES["pic1"]["name"]);
//$p1=$_POST['pword1'];

$s=$_POST['site'];
if (move_uploaded_file($_FILES["pic1"]["tmp_name"], $df1))
 { 

 
        $result=pg_query($connect,"insert into companyregistration(cid,cname,mobile,telephone,location,pincode,cin,email,password,type,site,status,logo) values('$cid','$cn','$cnum1','$cnum2','$cad','$pin','$cino','$cem','$cid','$cty','$s','$sta','$df1')");
        if($result)
        {
            echo"<script>alert('Succesfully registered');</script>";
            header('refresh:0.5,url=Proprietor.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            header('refresh:0.5,url=company.php');
        }
    }

}
?>