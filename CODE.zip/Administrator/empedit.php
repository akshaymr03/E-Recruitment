<?php
include 'connected.php';
if(isset($_POST['reset']))
{
$f1="employee/";
$df1=$f1 . basename($_FILES["pic1"]["name"]);
//$empid=$_POST['eid'];
$en1=$_POST['ename1'];
$en2=$_POST['ename2'];
$en3=$_POST['ename3'];
$an1=$_POST['aadhar1'];
$em=$_POST['email1'];
$ead=$_POST['add'];
$emob=$_POST['emob1'];
$sal=$_POST['salary'];
$desg=$_POST['desg1'];
$pin1=$_POST['pinc1'];
$dat1=$_POST['date1'];
$dat2=$_POST['date2'];
$eco=$_POST['ecode'];
$gen=$_POST['gender'];
$sta=$_POST['status'];
//$p2=$_POST['pword2'];
//$a=uniqid();
//$b=substr($a,9);
//$empid="EMP/".$b;
//if($p1==$p2)
//{
 if (move_uploaded_file($_FILES["pic1"]["tmp_name"], $df1))
 { 
   
        $result=pg_query($connect,"update employeeregistration set first='$en1',middle='$en2',last='$en3',aadhar='$an1',email='$em',address='$ead',mobile='$emob',salary='$sal',photo='$df1',designation='$desg',pincode='$pin1',dateofjoin='$dat1',dob='$dat2',password='$eco',gender='$gen',status='$sta' where empid='$eco'");
        if($result)
        {
            echo"<script>alert('Succesfully Updated');</script>";
           header('refresh:0.5,url=emptable.php');
        }
        else
        {
            echo"<script>alert('Not Updated');</script>";
            header('refresh:0.5,url=employeeupdate.php');
        }
    }
//}
 //else
 //{
    // echo"<script>alert('Password Miss Matching');</script>";
    // header('refresh:0.5,url=employee.php');
 }
?>
