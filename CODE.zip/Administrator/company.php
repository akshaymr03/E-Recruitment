<!DOCTYPE html>
<html lang="en">

<head>
    <title>White Collar</title>
    <!-- HTML5 Shim and Respond.js IE11 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 11]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    <!-- Meta -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="Free Datta Able Admin Template come up with latest Bootstrap 4 framework with basic components, form elements and lots of pre-made layout options" />
    <meta name="keywords" content="admin templates, bootstrap admin templates, bootstrap 4, dashboard, dashboard templets, sass admin templets, html admin templates, responsive, bootstrap admin templates free download,premium bootstrap admin templates, datta able, datta able bootstrap admin template, free admin theme, free dashboard template"/>
    <meta name="author" content="CodedThemes"/>

    <!-- Favicon icon -->
    <link rel="icon" href="assets/images/gitlab1.png" type="image/x-icon">
    <!-- fontawesome icon -->
    <link rel="stylesheet" href="assets/fonts/fontawesome/css/fontawesome-all.min.css">
    <!-- animation css -->
    <link rel="stylesheet" href="assets/plugins/animation/css/animate.min.css">
    <!-- vendor css -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body>
    <!-- [ Pre-loader ] start -->
    <!--div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div-->
    <!-- [ Pre-loader ] End -->
    <!-- [ navigation menu ] start -->
    <nav class="pcoded-navbar">
        <div class="navbar-wrapper">
            <div class="navbar-brand header-logo">
                <a href="index.php" class="b-brand">
                    <div class="b-bg">
                        <i class="feather icon-gitlab"></i>
                    </div>
                    <span class="b-title">White Collar</span>
                </a>
            </div>
            <div class="navbar-content scroll-div">
                <ul class="nav pcoded-inner-navbar">
                    <li class="nav-item pcoded-menu-caption">
                        <label>Administrator</label>
                    </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                        <a href="index.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-home"></i></span><span class="pcoded-mtext">Home</span></a>
                    </li>
                    <li class="nav-item pcoded-menu-caption">
                        <label>Registration</label>
                    </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item active">
                        <a href="Proprietor.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-bar-chart-2"></i></span><span class="pcoded-mtext">Company</span></a>
                    </li>
                    <!--li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                        <a href="employee.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">Employee</span></a>
                    </li-->
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                        <a href="vacancy.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Vacancy</span></a>
                    </li>
                   <li class="nav-item pcoded-menu-caption">
                        <label>Tables</label>
                    </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                    <a href="proptable.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-user"></i></span><span class="pcoded-mtext">Proprietor</span></a>
                </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                    <a href="comptable.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-bar-chart-2"></i></span><span class="pcoded-mtext">Company</span></a>
                </li>
                <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                    <a href="vactable.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-layers"></i></span><span class="pcoded-mtext">Vacancy</span></a>
                </li>
                <li class="nav-item pcoded-menu-caption">
                        <label>Feedback</label>
                    </li>
                    <li data-username="dashboard Default Ecommerce CRM Analytics Crypto Project" class="nav-item">
                    <a href="emptable.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-users"></i></span><span class="pcoded-mtext">Feedbacks</span></a>
                </li>
                    
                    <li class="nav-item pcoded-menu-caption">
                        <label>Logout</label>
                    </li>
                    <li class="nav-item">
                    <a href="login.php"  class="nav-link " title="Logout"><span class="pcoded-micon"><i class="feather icon-log-out"></i></span><span class="pcoded-mtext">Logout</span></a>
                </li>

                        <!--/ul-->
                    <!--/li-->
                    <!--li class="nav-item pcoded-menu-caption">
                        <label>Forms & table</label>
                    </li>
                    <li data-username="form elements advance componant validation masking wizard picker select" class="nav-item">
                        <a href="form_elements.html" class="nav-link "><span class="pcoded-micon"><i class="feather icon-file-text"></i></span><span class="pcoded-mtext">Form elements</span></a>
                    </li-->
                    <!--li data-username="Table bootstrap datatable footable" class="nav-item">
                        <a href="tbl_bootstrap.html" class="nav-link "><span class="pcoded-micon"><i class="feather icon-server"></i></span><span class="pcoded-mtext">Table</span></a>
                    </li-->
                    <!--li class="nav-item pcoded-menu-caption">
                        <label>Chart & Maps</label>
                    </li-->
                    <!--li data-username="Charts Morris" class="nav-item"><a href="chart-morris.html" class="nav-link "><span class="pcoded-micon"><i class="feather icon-pie-chart"></i></span><span class="pcoded-mtext">Chart</span></a></li>
                    <li data-username="Maps Google" class="nav-item"><a href="map-google.html" class="nav-link "><span class="pcoded-micon"><i class="feather icon-map"></i></span><span class="pcoded-mtext">Maps</span></a></li-->
                    <!--li class="nav-item pcoded-menu-caption">
                        <label>Pages</label>
                    </li>
                    <li data-username="Authentication Sign up Sign in reset password Change password Personal information profile settings map form subscribe" class="nav-item pcoded-hasmenu">
                        <a href="javascript:" class="nav-link "><span class="pcoded-micon"><i class="feather icon-lock"></i></span><span class="pcoded-mtext">Authentication</span></a>
                        <ul class="pcoded-submenu">
                            <li class=""><a href="auth-signup.html" class="" target="_blank">Sign up</a></li>
                            <li class=""><a href="auth-signin.html" class="" target="_blank">Sign in</a></li>
                        </ul>
                    </li>
                    <li data-username="Sample Page" class="nav-item"><a href="sample-page.html" class="nav-link"><span class="pcoded-micon"><i class="feather icon-sidebar"></i></span><span class="pcoded-mtext">Sample page</span></a></li-->
                    <!--li data-username="Disabled Menu" class="nav-item disabled"><a href="javascript:" class="nav-link"><span class="pcoded-micon"><i class="feather icon-power"></i></span><span class="pcoded-mtext">Disabled menu</span></a></li-->
                </ul>
            </div>
        </div>
    </nav>
    <!-- [ navigation menu ] end -->

    <!-- [ Header ] start -->
<header class="navbar pcoded-header navbar-expand-lg navbar-light">
        <div class="m-header">
            <a class="mobile-menu" id="mobile-collapse1" href="javascript:"><span></span></a>
            <a href="index.php" class="b-brand">
                   <div class="b-bg">
                       <i class="feather icon-trending-up"></i>
                   </div>
                   <span class="b-title">White Collar</span>
               </a>
        </div>
        
        
    </header>    <!-- [ Header ] end -->

    <!-- [ Main Content ] start -->
    <div class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <!-- [ breadcrumb ] start -->
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10">Registration</h5>
                                    </div>
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php"><i class="feather icon-home"></i></a></li>
                                        <li class="breadcrumb-item"><a href="javascript:">Registration</a></li>
                                        <li class="breadcrumb-item"><a href="javascript:">Company</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- [ breadcrumb ] end -->
                    <div class="main-body">
                        <div class="page-wrapper">
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="card">
                                       <?php
                                       if(isset($_GET['cmpid']))
                                       {
                                        $cid=$_GET['cmpid'];
                                       ?>
                                       <form action="companyreg.php" method="POST" enctype="multipart/form-data">
                                        <div  class="card-body">
                                                <h5 class="mt-5">Company</h5>
                                                <hr>
                                                <div class="col-md-6">
                                                    
                                                
                                                    <div class="form-group">
                                                        <label>Company Name</label>
                                                        <input type="text" class="form-control"  name="cname" placeholder="Enter company name" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Mobile</label>
                                                                                                 
                                                                <input type="tel" name="cm" placeholder="9876543210" class="form-control" pattern="[0-9]{10}" required>
                                                          
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Telephone</label>
                                                        <input type="tel" name="cc" placeholder="04801234567" class="form-control" pattern="[0-9]{4}[0-9]{7}">
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleFormControlTextarea1">Location</label>
                                                        <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Enter company address" name="loc" required></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Pin Code</label>
                                                        <input type="tel" class="form-control"  name="pinc" placeholder="Enter pin code" pattern="[0-9]{6}" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Corporate Identification Number</label>
                                                        <input type="text" class="form-control" name="cin" placeholder="Enter CIN no." minlength="21" maxlength="21" required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="exampleInputEmail1">Email address</label>
                                                            <input type="email" class="form-control" name="cemail" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" required>
                                                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                                    </div>
                                                    </div>
                                                    <!--div class="col-md-6">
                                                        <label>Password</label>
                                                        <input type="password" class="form-control" id="password"  name="pword1" placeholder="Enter the password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
                                                    </div-->
                                                    <!--div class="col-md-6">
                                                        <label>Re-Enter Password</label>
                                                        <input type="password" id="password_confirm" class="form-control"  name="pword2" placeholder="Enter company name" required-->
                                                    <!--/div>
                                                    <div class="col-md-6"-->
                                                    <!--script language='javascript' type='text/javascript'>
                                                      function check(input) {
                                                     if (input.value != document.getElementById('pword1').value) {
                                                          input.setCustomValidity('Password Must be Matching.');
                                                         } else {
                                                      // input is valid -- reset the error message
                                                      input.setCustomValidity('');
                                                     }
                                                    }
                                                   </script>
                                               </div-->
                                                    <div class="col-md-6">
                                                        <label>Company Type</label>
                                                        <select class="mb-3 form-control form-control-lg" name="ctype" required>
                                                            <option>Select Type</option>
                                                            <option>Construction</option>
                                                            <option>Corodinator</option>
                                                            <option>Employer</option>
                                                            <option>Financial Career</option>
                                                            <option>Information Technology</option>
                                                            <option>Marketing</option>
                                                            <option>Quality check</option>
                                                            <option>Real Estate</option>
                                                            <option>Sales</option>
                                                            <option>Supporting</option>
                                                            <option>Teaching</option> 
                                                            <option>Other</option>
                                                        </select>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <label>Web Site</label>
                                                        <input type="text" class="form-control"  name="site" placeholder="Enter company web site" required>
                                                    </div>
                                                    <div class="col-md-6">
                                                                    <label>Photo</label>
                                                                    <input type="file" name="pic1" class="form-control" required>
                                                                    
                                                                </div> 
                                                                <div class="col-md-6">
                                                            <label for="exampleFormControlSelect1">Status</label>
                                                            <select name="status" class="form-control" id="exampleFormControlSelect1">
                                                                <option>Active</option>
                                                                <option>Inactive</option>
                                                                
                                                            </select>
                                                        </div>                        
                                                    <input type="hidden" name="cid1" value="<?php echo $cid;?>">
                                                    <div class="form-group">
                                                        <br>

                                                        <button type="submit" name="okay" class="btn btn-primary">SUBMIT</button>
                                                        <button type="reset" class="btn btn-primary">CLEAR</button>
                                                    </div>

                                                </form>
                                                <?php
                                            }
                                            ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

