<?php
session_start();
include 'connected.php';
if(isset($_POST['ok']))
{
 $u=$_POST['uemail'];
 $p=$_POST['upword'];

 $res=pg_query($connect,"select * from userregistration where uemail='$u' and(upassword='$p' and status='Active')");
    if(pg_num_rows($res)>0)
    {   
    	$_SESSION['uemail']=$u;
     echo"<script>alert('Succesfully registered');</script>";
     header('location:jobindex.php');
    
    }
    else
    {
        //echo"<script>alert('LOGIN FAILED! Try Again');</script>";
         header('location:login1.php');
    }
}
?>
