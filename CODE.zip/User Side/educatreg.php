<?php
include 'connected.php';
if(isset($_POST['register']))
{   
 $uid=$_POST['uid1'];
 $uedu1=$_POST['hiquali'];
 $ucourse=$_POST['course'];
 $uspecial=$_POST['special'];
$ucol=$_POST['college'];
 $uyr1=$_POST['year1'];
 $uperc1=$_POST['percent1'];

 $uedu2=$_POST['quali'];
 $uboard=$_POST['board'];
 $uyr2=$_POST['year2'];
$umd=$_POST['medium'];
 $uperc2=$_POST['percent2'];
 $uskil=$_POST['skill'];
$result=pg_query($connect,"insert into usereducation(userid,ueducat1,ucourse,uspecial,ucollege,uyear1,ueducat2,uboard,uyear2,umedium,upercent1,uskill,upercent2) values('$uid','$uedu1','$ucourse','$uspecial','$ucol','$uyr1','$uedu2','$uboard','$uyr2','$umd','$uperc1','$uskil','$uperc2')");
        if($result)
        {
            echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=login.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            header('refresh:0.5,url=education.php');
        }
    }

?>