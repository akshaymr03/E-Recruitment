<?php
include 'connected.php';

if(isset($_POST['submit']))
{
$f1="user_resume/";
$df1=$f1 . basename($_FILES["uresume"]["name"]);
$f2="user_photo/";
$df2=$f2 . basename($_FILES["uphoto"]["name"]);
//$empid=$_POST['eid'];
$un=$_POST['uname'];
$umail=$_POST['uemail'];
$umob=$_POST['umobile'];
$uadd=$_POST['uloc'];
$stat="Active";
$gen=$_POST['gender'];
$uid=$_POST['userid'];
$formate1=pathinfo($df1,PATHINFO_EXTENSION);
$formate2=pathinfo($df2,PATHINFO_EXTENSION);
//if($p1==$p2)
//{
 if (move_uploaded_file($_FILES["uresume"]["tmp_name"], $df1))
 {
  if (move_uploaded_file($_FILES["uphoto"]["tmp_name"], $df2))
 { 
   
        $result=pg_query($connect,"update userregistration set uname='$un',uemail='$umail',umobile='$umob',uaddress='$uadd',uresume='$df1',status='$stat',gender='$gen',photo='$df2' where userid='$uid'");
        if($result)
        {
            //echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=editprof.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            //header('refresh:0.5,url=personal.php');
        }
    }
    else
    {
     $result=pg_query($connect,"update userregistration set uname='$un',uemail='$umail',umobile='$umob',uaddress='$uadd',uresume='$df1',status='$stat',gender='$gen' where userid='$uid'");
        if($result)
        {
            //echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=editprof.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            //header('refresh:0.5,url=personal.php');
        }   
    }

 }
 else
 {
     $result=pg_query($connect,"update userregistration set uname='$un',uemail='$umail',umobile='$umob',uaddress='$uadd',status='$stat',gender='$gen' where userid='$uid'");
        if($result)
        {
            //echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=editprof.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            //header('refresh:0.5,url=personal.php');
        }   
 }
}
?>