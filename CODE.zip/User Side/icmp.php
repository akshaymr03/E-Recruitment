
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
		<meta name="description" content="JobBoard - HTML Template" />
	<meta property="og:title" content="JobBoard - HTML Template" />
	<meta property="og:description" content="JobBoard - HTML Template" />
	<meta property="og:image" content="JobBoard - HTML Template" />
	<meta name="format-detection" content="telephone=no">
	
	<!-- FAVICONS ICON -->
	<link rel="icon" href="images/favicon.ico" type="image/x-icon" />
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png" />
	
	<!-- PAGE TITLE HERE -->
	<title>WhiteCollar</title>
	
	<!-- MOBILE SPECIFIC -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<!--[if lt IE 9]>
	<script src="js/html5shiv.min.js"></script>
	<script src="js/respond.min.js"></script>
	<![endif]-->
	
	<!-- STYLESHEETS -->
	<link rel="stylesheet" type="text/css" href="css/plugins.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/templete.css">
	<link class="skin" rel="stylesheet" type="text/css" href="css/skin/skin-1.css">
	<link rel="stylesheet" href="plugins/datepicker/css/bootstrap-datetimepicker.min.css"/>
	<!-- Revolution Slider Css -->
	<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/layers.css">
	<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/settings.css">
	<link rel="stylesheet" type="text/css" href="plugins/revolution/revolution/css/navigation.css">
	<!-- Revolution Navigation Style -->
</head><body id="bg">
<div class="page-wraper">
	<!-- header -->
    <header class="site-header mo-left header fullwidth">
		<!-- main header -->
        <div class="sticky-header main-bar-wraper navbar-expand-lg">
            <div class="main-bar clearfix">
                <div class="container clearfix">
                    <!-- website logo -->
                    <div class="logo-header mostion">
						<a href="jobindex.php"><img src="images/logo1.png" class="logo" alt=""></a>
					</div>
                    <!-- nav toggle button -->
                    <!-- nav toggle button -->
                    <button class="navbar-toggler collapsed navicon justify-content-end" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
						<span></span>
						<span></span>
						<span></span>
					</button>
                    <!-- extra nav -->
                    
                    <!-- Quik search -->
                    <div class="dez-quik-search bg-primary">
                        <form action="#">
                            <input name="search" value="" type="text" class="form-control" placeholder="Type to search">
                            <span id="quik-search-remove"><i class="flaticon-close"></i></span>
                        </form>
                    </div>
                    <!-- main nav -->
                    <div class="header-nav navbar-collapse collapse justify-content-start" id="navbarNavDropdown">
                        <ul class="nav navbar-nav">
							<li>
								<a href="index.php">Home</i></a>
							</li>
							<li>
                                <a href="iapply.php">Jobs</i></a>
                            </li>
							<li class="active">
								<a href="icmp.php">Company</i></a>
							</li>
							
							<!--li>
								<a href="#">For Employers <i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li><a href="browse-candidates.html" class="dez-page">Browse Candidates</a></li>
									<li><a href="submit-resume.html" class="dez-page">Submit Resume</a></li>
								</ul>
							</li>
							<li>
								<a href="#">Pages <i class="fa fa-chevron-down"></i></a>
								<ul class="sub-menu">
									<li><a href="about-us.html" class="dez-page">About Us</a></li>
									<li><a href="coming-soon.html" class="dez-page">Coming Soon</a></li>
									<li><a href="error-404.html" class="dez-page">Error 404</a></li>
									<li><a href="#" class="dez-page">Portfolio</a>
										<ul class="sub-menu">
											<li><a href="portfolio-grid-2.html" class="dez-page">Portfolio Grid 2 </a></li>
											<li><a href="portfolio-grid-3.html" class="dez-page">Portfolio Grid 3 </a></li>
											<li><a href="portfolio-grid-4.html" class="dez-page">Portfolio Grid 4 </a></li>
										</ul>
									</li>
									<li><a href="login.html" class="dez-page">Login</a></li>
									<li><a href="register.html" class="dez-page">Register</a></li>
									<li><a href="contact.html" class="dez-page">Contact Us</a></li>
								</ul>
							</li-->

						</ul>	
                    </div>
                </div>
            </div>
        </div>
        <!-- main header END -->
    </header>
     <!-- Content -->
    <div class="page-content bg-white">
        <!-- inner page banner -->
        <div class="dez-bnr-inr overlay-black-middle" style="background-image:url(images/banner/bnr1.jpg);">
            <div class="container">
                <div class="dez-bnr-inr-entry">
                    <h1 class="text-white">Companies</h1>
					<!-- Breadcrumb row -->
					<div class="breadcrumb-row">
						<ul class="list-inline">
							<li><a href="#">Home</a></li>
							<li>Companies</li>
						</ul>
					</div>
					<!-- Breadcrumb row END -->
                </div>
            </div>
        </div>
        <!-- inner page banner END -->
        <!-- contact area -->
        <div class="content-block">
			<!-- Find Job -->
			<div class="section-full bg-white content-inner">
				<div class="container">
					<div class="d-flex job-title-bx section-head">
                    <div class="mr-auto">
                        <h2 class="m-b5">Companies waiting for you</h2>
                       
                    </div>
                    
                </div>
					<!--div class="site-filters clearfix center  m-b40">
						<ul class="filters" data-toggle="buttons">
							<li data-filter="" class="btn active">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>A</span></a> 
							</li>
							<li data-filter="web" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>B</span></a> 
							</li>
							<li data-filter="advertising" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>C</span></a> 
							</li>
							<li data-filter="branding" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>D</span></a> 
							</li>
							<li data-filter="design" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>E</span></a> 
							</li>
							<li data-filter="photography" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>F</span></a> 
							</li>
							<li data-filter="" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>G</span></a> 
							</li>
							<li data-filter="web" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>H</span></a> 
							</li>
							<li data-filter="advertising" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>I</span></a> 
							</li>
							<li data-filter="branding" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>J</span></a> 
							</li>
							<li data-filter="design" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>K</span></a> 
							</li>
							<li data-filter="photography" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>L</span></a> 
							</li>
							<li data-filter="" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>M</span></a> 
							</li>
							<li data-filter="web" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>N</span></a> 
							</li>
							<li data-filter="advertising" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>O</span></a> 
							</li>
							<li data-filter="branding" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>P</span></a> 
							</li>
							<li data-filter="design" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>Q</span></a> 
							</li>
							<li data-filter="photography" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>R</span></a> 
							</li>
							<li data-filter="" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>S</span></a> 
							</li>
							<li data-filter="web" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>T</span></a> 
							</li>
							<li data-filter="advertising" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>U</span></a> 
							</li>
							<li data-filter="branding" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>V</span></a> 
							</li>
							<li data-filter="design" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>W</span></a> 
							</li>
							<li data-filter="photography" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>X</span></a> 
							</li>
							<li data-filter="" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>Y</span></a> 
							</li>
							<li data-filter="web" class="btn">
								<input type="radio">
								<a href="#" class="site-button-secondry radius-sm"><span>Z</span></a> 
							</li>
						</ul>
					</div-->
					<!--ul id="masonry" class="dez-gallery-listing gallery-grid-4 gallery mfp-gallery">
						<li class="web card-container col-lg-3 col-md-4 col-sm-4">
							<div class="dez-gallery-box">
								<div class="dez-media overlay-black-light">
									<a href="javascript:void(0);"> <img src="images/gallery/pic1.jpg"  alt=""> </a>
									<div class="overlay-icon overlay-logo">
										<img src="images/logo/logo/logo1.png" alt="">
									</div>
								</div>
							</div>
						</li-->
<div class="row">
					<div class="col-lg-9">
						<ul class="post-job-bx">
							<?php
                         include 'connected.php';
                         $result1=pg_query($connect,"select * from companyregistration where status='Active'");
                          while($res1=pg_fetch_array($result1))
                          {
                          	?>
							<li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="/../PROJECT--E RECRUITMENT/Administrator/<?php echo $res1[12];?>"/></span>
										</div>
										<div class="job-post-info">
											<h4><?php echo $res1[1];?></h4>
											<ul>
											
												<li><?php echo $res1[4];?></li>
											</ul>
											<ul>
												<li><?php echo $res1[7];?></li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Mobile : <?php echo $res1[2];?></span>
											<span>Tele : <?php echo $res1[3];?></span>
										</div>
									</div>
									<!--span class="post-like fa fa-heart-o"></span-->
								</a>
							</li>
							<!--li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="images/logo/icon1.png"/></span>
										</div>
										<div class="job-post-info">
											<h4>Digital Marketing Executive</h4>
											<ul>
												<li><i class="fa fa-map-marker"></i> Sacramento, California</li>
												<li><i class="fa fa-bookmark-o"></i> Full Time</li>
												<li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Full Time</span>
										</div>
										<div class="salary-bx">
											<span>$1200 - $ 2500</span>
										</div>
									</div>
									<span class="post-like fa fa-heart-o"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="images/logo/icon1.png"/></span>
										</div>
										<div class="job-post-info">
											<h4>Digital Marketing Executive</h4>
											<ul>
												<li><i class="fa fa-map-marker"></i> Sacramento, California</li>
												<li><i class="fa fa-bookmark-o"></i> Full Time</li>
												<li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Full Time</span>
										</div>
										<div class="salary-bx">
											<span>$1200 - $ 2500</span>
										</div>
									</div>
									<span class="post-like fa fa-heart-o"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="images/logo/icon1.png"/></span>
										</div>
										<div class="job-post-info">
											<h4>Digital Marketing Executive</h4>
											<ul>
												<li><i class="fa fa-map-marker"></i> Sacramento, California</li>
												<li><i class="fa fa-bookmark-o"></i> Full Time</li>
												<li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Full Time</span>
										</div>
										<div class="salary-bx">
											<span>$1200 - $ 2500</span>
										</div>
									</div>
									<span class="post-like fa fa-heart-o"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="images/logo/icon1.png"/></span>
										</div>
										<div class="job-post-info">
											<h4>Digital Marketing Executive</h4>
											<ul>
												<li><i class="fa fa-map-marker"></i> Sacramento, California</li>
												<li><i class="fa fa-bookmark-o"></i> Full Time</li>
												<li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Full Time</span>
										</div>
										<div class="salary-bx">
											<span>$1200 - $ 2500</span>
										</div>
									</div>
									<span class="post-like fa fa-heart-o"></span>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="d-flex m-b30">
										<div class="job-post-company">
											<span><img src="images/logo/icon1.png"/></span>
										</div>
										<div class="job-post-info">
											<h4>Digital Marketing Executive</h4>
											<ul>
												<li><i class="fa fa-map-marker"></i> Sacramento, California</li>
												<li><i class="fa fa-bookmark-o"></i> Full Time</li>
												<li><i class="fa fa-clock-o"></i> Published 11 months ago</li>
											</ul>
										</div>
									</div>
									<div class="d-flex">
										<div class="job-time mr-auto">
											<span>Full Time</span>
										</div>
										<div class="salary-bx">
											<span>$1200 - $ 2500</span>
										</div>
									</div>
									<span class="post-like fa fa-heart-o"></span>
								</a>
							</li-->
							<?php
						
						}
						?>
						</ul>				</div>
			</div>
            <!-- Find Job END -->
		</div>
    </div>
</div>
</div>
</div>

    <!-- Content END-->
	<!-- Footer -->
    <footer class="site-footer">
        <div class="footer-top">
            <div class="container">
                <div class="row">
					<div class="col-xl-5 col-lg-4 col-md-12 col-sm-12">
                        <div class="widget">
                            <img src="images/logo-white1.png" width="180" class="m-b15" alt=""/>
							<p class="text-capitalize m-b20">There is no good or bad experiences, Just Learning Experiences. Come Create your FUTURE</p>
                            
                        </div>
                    </div>
					<div class="col-xl-5 col-lg-5 col-md-8 col-sm-8 col-12">
                        <div class="widget border-0">
                            <h5 class="m-b30 text-white">Log IN</h5>
                            <ul class="list-2 list-line">
                               
                                <li><a href="recrlog.php">Recruiters</a></li>
                                

                                
								
                            </ul>
                        </div>
                    </div>
					<div class="col-xl-2 col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="widget border-0">
                            <h5 class="m-b30 text-white">Know more!!!</h5>
                            <ul class="list-2 w10 list-line">
                               <li><a href="feedback.php">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>
				</div>
            </div>
        </div>
        <!-- footer bottom part -->
        <div class="footer-bottom">
            <div class="container">
               <div class="row">
                    <div class="col-lg-12 text-center"><span>White<font color="#0356fc">Collar</font></span></div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer END -->
    <!-- scroll top button -->
    <button class="scroltop fa fa-arrow-up" ></button>
</div>
<!-- JAVASCRIPT FILES ========================================= -->
<script src="js/jquery.min.js"></script><!-- JQUERY.MIN JS -->
<script src="plugins/wow/wow.js"></script><!-- WOW JS -->
<script src="plugins/bootstrap/js/popper.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<!script src="plugins/bootstrap/js/bootstrap.min.js"></script><!-- BOOTSTRAP.MIN JS -->
<script src="plugins/bootstrap-select/bootstrap-select.min.js"></script><!-- FORM JS -->
<script src="plugins/bootstrap-touchspin/jquery.bootstrap-touchspin.js"></script><!-- FORM JS -->
<script src="plugins/magnific-popup/magnific-popup.js"></script><!-- MAGNIFIC POPUP JS -->
<script src="plugins/counter/waypoints-min.js"></script><!-- WAYPOINTS JS -->
<script src="plugins/counter/counterup.min.js"></script><!-- COUNTERUP JS -->
<script src="plugins/imagesloaded/imagesloaded.js"></script><!-- IMAGESLOADED -->
<script src="plugins/masonry/masonry-3.1.4.js"></script><!-- MASONRY -->
<script src="plugins/masonry/masonry.filter.js"></script><!-- MASONRY -->
<script src="plugins/owl-carousel/owl.carousel.js"></script><!-- OWL SLIDER -->
<script src="plugins/rangeslider/rangeslider.js" ></script><!-- Rangeslider -->
<script src="js/custom.js"></script><!-- CUSTOM FUCTIONS  -->
<script src="js/dz.carousel.js"></script><!-- SORTCODE FUCTIONS  -->
<script src='js/recaptcha/api.js'></script> <!-- Google API For Recaptcha  -->
<script src="js/dz.ajax.js"></script><!-- CONTACT JS  -->
<script src="plugins/paroller/skrollr.min.js"></script><!-- PAROLLER -->
<!-- Go to www.addthis.com/dashboard to customize your tools --> 

</body>

</html>
