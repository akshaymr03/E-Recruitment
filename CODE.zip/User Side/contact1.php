<?php
include 'connected.php';
if(isset($_POST['submit']))
{
$na=$_POST['name'];
$nu=$_POST['contact'];
$em=$_POST['email'];
$add=$_POST['address'];
$msg=$_POST['message'];
 $result=pg_query($connect,"insert into contact(name,number,address,email,message) values('$na','$nu','$add','$em','$msg')");
  if($result)
    {
         echo"<script>alert('Succesfully registered');</script>";
         header('refresh:0.5,url=feedback.php');
    }
     else
    {
        echo"<script>alert('Not registered');</script>";
        header('refresh:0.5,url=feedback.php');
    }
}