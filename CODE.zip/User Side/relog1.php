<?php
// Start the session
session_start();
include 'connected.php';
if(isset($_POST['ok']))
{
 $e=$_POST['email1'];
 $p=$_POST['pword'];

 $res=pg_query($connect,"select * from companyregistration where status='Active' and(email='$e' and password='$p')");
    if(pg_num_rows($res)>0)
    {   
     $_SESSION['email1']=$e;
     header('location:cindex.php');

    
    }
    else
    {
       header('location:relog2.php');
    }
}
?>