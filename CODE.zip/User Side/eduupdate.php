<?php
include 'connected.php';
if(isset($_POST['register']))
{   
 $uid=$_POST['uid1'];
 $uedu1=$_POST['hiquali'];
 $ucourse=$_POST['course'];
 $uspecial=$_POST['special'];
$ucol=$_POST['college'];
 $uyr1=$_POST['year1'];
 $uperc1=$_POST['percent1'];

 $uedu2=$_POST['quali'];
 $uboard=$_POST['board'];
 $uyr2=$_POST['year2'];
$umd=$_POST['medium'];
 $uperc2=$_POST['percent2'];
 $uskil=$_POST['skill'];
 //echo $uid,$uedu1,$ucourse,$uspecial,$ucol,$uyr1,$uperc1,$uedu2,$uboard,$uyr2,$umd,$uperc2,$uskil;
 $result=pg_query($connect,"update usereducation set ueducat1='$uedu1',ucourse='$ucourse',uspecial='$uspecial',ucollege='$ucol',uyear1='$uyr1',ueducat2='$uedu2',uboard='$uboard',uyear2='$uyr2',umedium='$umd',upercent1='$uperc1',uskill='$uskil',upercent2='$uperc2' where userid='$uid'");
  if($result)
        {
            //echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=editeduprof.php');
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            //header('refresh:0.5,url=personal.php');
        }
    }
       ?>