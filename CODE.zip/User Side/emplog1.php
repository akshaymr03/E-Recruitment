<?php
include 'connected.php';
if(isset($_POST['ok']))
{
 $e=$_POST['email'];
 $p=$_POST['pword'];


 $res=pg_query($connect,"select from employeeregistration where status='Active' and(email='$e' and password='$p')");
    if(pg_num_rows($res)>0)
    { 
     
     header('location:index.php');
    
    }
    else
    {
        echo"<script>alert('LOGIN FAILD! Try Again');</script>";
        header('location:emplog.php');
    }
}
?>