<?php
include 'connected.php';
$a=uniqid();
$uid="JS/".$a;
if(isset($_POST['submit']))
{
$f1="user_resume/";
$df1=$f1 . basename($_FILES["uresume"]["name"]);
$f2="user_photo/";
$df2=$f2 . basename($_FILES["uphoto"]["name"]);
//$empid=$_POST['eid'];
$un=$_POST['uname'];
$umail=$_POST['uemail'];
$upword=$_POST['upass'];
$umob=$_POST['umobile'];
$uadd=$_POST['uloc'];
$stat="Active";
$gen=$_POST['gender'];
$formate1=pathinfo($df1,PATHINFO_EXTENSION);
$formate2=pathinfo($df2,PATHINFO_EXTENSION);
//if($p1==$p2)
//{
 if (move_uploaded_file($_FILES["uresume"]["tmp_name"], $df1))
 {
  if (move_uploaded_file($_FILES["uphoto"]["tmp_name"], $df2))
 { 
   
        $result=pg_query($connect,"insert into userregistration(userid,uname,uemail,upassword,umobile,uaddress,uresume,status,gender,photo) values('$uid','$un','$umail','$upword','$umob','$uadd','$df1','$stat','$gen','$df2')");
        if($result)
        {
            echo"<script>alert('Succesfully registered');</script>";
           header('refresh:0.5,url=education.php?userid='.$uid);
        }
        else
        {
            echo"<script>alert('Not registered');</script>";
            header('refresh:0.5,url=personal.php');
        }
    }

 }
}
?>